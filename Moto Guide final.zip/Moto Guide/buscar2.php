<?php
if(isset($_POST['palabra'])){
    require_once "filtro.php";
    require_once 'config/db_connect.php';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

 


</br></br>
<div class="form-group row">
                <div class="col-sm-10">
                    <a href="./index.php" class="btn btn-danger">Volver</a>
                </div>
            </div>
</body>
</html>