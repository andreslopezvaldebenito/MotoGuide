<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

    <title>MOTO GUIDE Resultado</title>
</head>
<body>

    <!-- begin menu -->
    <?php include('./botones/menu2.php');?>
    <!-- end menu -->
    <div class="container">
     <h2 class="mt-5 text-uppercase">Resultados Filtrados por Palabras claves</h2>



<?php

    $palabra=$_POST['palabra'];
    
    require('config/db_connect.php');
    $conexion = connect();
    $query="SELECT * FROM productos WHERE descripcion_producto LIKE '%$palabra%'";
    $consulta3=mysqli_query ($conexion, $query);

    $i=1;
    if ($consulta3->num_rows>=1){
        echo '<table class="table table-sm">';
            echo '<thead>';
            echo '<tr>';
            echo '<th class="table-header" >&num; </th>';
            echo '<th class="table-header" >Tipo de producto </th>';
            echo '<th class="table-header" >Descripcion </th>';
            echo '<th class="table-header" >Tipo de moto </th>';
            echo '<th class="table-header" >Marca de moto </th>';
            echo '<th class="table-header" >Modelo de moto </th>';
            echo '<th class="table-header" >Tienda </th>';
            echo '<th class="table-header" >Precio </th>';
            echo '<th class="table-header" >Foto</th>';
      echo '<th class="table-header" >Mapa</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
		while($fila=$consulta3->fetch_array(MYSQLI_ASSOC)){
			echo '<tr>';
              echo '<td>' . $i++ . '</td>';
              echo '<td>' . $fila['tipo_producto'] . '</td>';
              echo '<td>' . $fila['descripcion_producto'] . '</td>';
              echo '<td>' . $fila['tipo_moto'] . '</td>';
              echo '<td>' . $fila['marca_moto'] . '</td>';
              echo '<td>' . $fila['modelo_moto'] . '</td>';
              echo '<td>' . $fila['tienda'] . '</td>';
              echo '<td>' . $fila['precio_producto'] . '</td>';
              echo '<td><a href="' . $fila['imagen']  . '"><i class="fas fa-pencil-alt"></i></a></td>';
              echo '<td><a href="' . $fila['mapa']  . '"><i class="fas fa-map"></i></a></td>';

              echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
          } else {
            echo '<p class="alert alert-warning">No hay resultados</p>';
          }

?>
</body>
</html>