<?php

require('./config/db_connect.php');

if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
    $sql = 'UPDATE productos SET tipo_producto=?, descripcion_producto=?, tipo_moto=?, marca_moto=?,modelo_moto=?, tienda=?, precio_producto=?, imagen=?, mapa=? WHERE cod_producto=?';
    if ($stmt = mysqli_prepare($conexion, $sql)) {
        $cod_producto = $_POST['cod_producto'];
        $tipo_producto = $_POST['tipo_producto'];
        $descripcion_producto=$_POST['descripcion_producto'];
        $tipo_moto = $_POST['tipo_moto'];
        $marca_moto = $_POST['marca_moto'];
        $modelo_moto = $_POST['modelo_moto'];        
        $tienda = $_POST['tienda']; 
        $precio_producto = $_POST['precio_producto']; 
        $imagen = $_POST['imagen']; 
        $mapa=$_POST['mapa'];
        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt,'ssssssissi', $tipo_producto,$descripcion_producto, $tipo_moto,$marca_moto,$modelo_moto,$tienda,$precio_producto,$imagen,$mapa,$cod_producto);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue editado correctamente
            header("Location: producto.php?msg=2");
        }

        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);

} elseif (!empty($_GET['cod_producto'])) {
    $conexion = connect();
    $sql = 'SELECT * FROM productos WHERE cod_producto=?';
    
    # inicializa  una sentencia y devuelve un objeto para usarlo con mysqli_stmt_prepare()
    $stmt = mysqli_stmt_init($conexion);

    if (mysqli_stmt_prepare($stmt, $sql)) {
        
        # vincular parametros
        mysqli_stmt_bind_param($stmt, 'i', $_GET['cod_producto']);

        # ejecutar consulta
        if (mysqli_stmt_execute($stmt)) {

            # vincular variables de resultados
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_array($result);
            
            $cod_producto = $_GET['cod_producto'];
            $tipo_producto = $row['tipo_producto'];
            $descripcion_producto=$row['descripcion_producto'];
            $tipo_moto = $row['tipo_moto'];
            $marca_moto = $row['marca_moto'];
            $modelo_moto = $row['modelo_moto'];        
            $tienda = $row['tienda']; 
            $precio_producto = $row['precio_producto']; 
            $imagen = $row['imagen'];
            $mapa=$row['mapa'];
            $msg = '';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion); # cerrar la conexion
} else {
            $cod_producto = '';
            $tipo_producto ='';
            $descripcion_producto='';
            $tipo_moto = '';
            $marca_moto = '';
            $modelo_moto = '';     
            $tienda = '';
            $precio_producto = '';
            $imagen = '';
            $mapa='';
            $msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>CRUD: Agregar</title>
</head>
<body>
   <!-- begin menu -->
   <?php include('./botones/menu3.php');?>
    <!-- end menu -->
    
    <div class="container">
        <h2 class="mt-5 text-uppercase">Editar</h2>

        <?php echo $msg; ?>

        <form action="./editar_producto.php" method="post">
			<div class="form-group row">
				<label for="cod_producto" class="col-sm-2 col-form-label">Codigo de Producto</label>
				<div class="col-sm-10">
					<input type="cod_producto" class="form-control" id="cod_producto" name="cod_producto" value="<?php echo $cod_producto;?>"readonly>
				</div>
			</div>
			<div class="form-group row">
						<label for="tipo_producto" class="col-sm-2 col-form-label">Tipo de producto</label>
						<div class="col-sm-10">
							<input type="tipo_producto" class="form-control" id="tipo_producto" name="tipo_producto" value="<?php echo $tipo_producto;?>">
						</div>
					</div>
			<div class="form-group row">
				<label for="descripcion_producto" class="col-sm-2 col-form-label">Descripcion</label>
				<div class="col-sm-10">
					<input type="descripcion_producto" class="form-control" id="descripcion_producto" name="descripcion_producto" value="<?php echo $descripcion_producto;?>">
				</div>
			</div>
			<div class="form-group row">
				<label for="tipo_moto" class="col-sm-2 col-form-label">Tipo de moto </label>
				<div class="col-sm-10">
					<input type="tipo_moto" class="form-control" id="tipo_moto" name="tipo_moto" value="<?php echo $tipo_moto;?>">
				</div>
			</div>
			<div class="form-group row">
				<label for="marca_moto" class="col-sm-2 col-form-label">Marca de moto</label>
				<div class="col-sm-10">
					<input type="marca_moto" class="form-control" id="marca_moto" name="marca_moto" value="<?php echo $marca_moto;?>">
				</div>
			</div>
			<div class="form-group row">
				<label for="modelo_moto" class="col-sm-2 col-form-label">Modelo de moto</label>
				<div class="col-sm-10">
					<input type="modelo_moto" class="form-control" id="modelo_moto" name="modelo_moto" value="<?php echo $modelo_moto;?>">
				</div>
			</div>
			<div class="form-group row">
				<label for="tienda" class="col-sm-2 col-form-label">Tienda</label>
				<div class="col-sm-10">
					<input type="tienda" class="form-control" id="tienda" name="tienda" value="<?php echo $tienda;?>">
				</div>
			</div>
			<div class="form-group row">
				<label for="precio_producto" class="col-sm-2 col-form-label">Precio</label>
				<div class="col-sm-10">
					<input type="precio_producto" class="form-control" id="precio_producto" name="precio_producto" value="<?php echo $precio_producto;?>">
				</div>
			</div>
            <div class="form-group row">
						<label for="imagen" class="col-sm-2 col-form-label">Link de Imagen</label>
						<div class="col-sm-10">
							<input type="imagen" class="form-control" id="imagen" name="imagen" value="<?php echo $imagen;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="mapa" class="col-sm-2 col-form-label">Link del Mapa</label>
						<div class="col-sm-10">
							<input type="mapa" class="form-control" id="mapa" name="mapa" value="<?php echo $mapa;?>">
						</div>
					</div>
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <a href="./producto.php" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>     
    </div>
        </form>
        </body>
</html>