<?php
require_once('config/db_connect.php');

if (isset($_GET['msg'])) {
  switch ($_GET['msg']) {
    case 0:
      $msg = '<p class="alert alert-danger">El registro de tienda no fue agregado.</p>';
      break;
    case 1:
      $msg = '<p class="alert alert-success">El registro de tienda fue agregado existosamente.</p>';
      break;
    case 2:
      $msg = '<p class="alert alert-success">El registro de tienda fue actualizado exitosamente.</p>';
      break;
    case 3:
      $msg = '<p class="alert alert-success">El registro de tienda fue eliminado existosamente.</p>';
      break;
    case 4:
      $msg = '<p class="alert alert-warning">El registro de tienda no fue eliminado.</p>';
      break;
    default:
      $msg = '';
      break;
  }
}

$conexion = connect();
$sql = 'SELECT * FROM tiendas';
/* 
mysqli_query($link, $sql): realiza una consulta a la base de datos. Retorna: 
  - objeto mysqli_result() de resultados obtenidos a partir de la consulta.
  - FALSE en caso de error.
  - TRUE en caso de exito de otra consulta sin retorno de datos.
*/
$result = mysqli_query($conexion, $sql);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

	
    <title>MOTO GUIDE Tiendas</title>
</head>
<body>
        <!-- begin menu -->
				<?php include('./botones/menu.php');?>
    <!-- end menu -->
    
	 <div class="container">
	 <h2 class="mt-5 text-uppercase">Nuestras sucursales</h2>
	 <br></br>
        <?php
			  if (isset($msg)) {
				echo $msg;
			  }
			  
			  if (mysqli_num_rows($result) > 0) {
				# crear tabla
				echo '<table class="table table-sm">';
				echo '<thead>';
				echo '<tr>';
				echo '<th class="table-header" >&num; </th>';
				echo '<th class="table-header" >Nombre de Tienda </th>';
				echo '<th class="table-header" >Direccion de la Tienda </th>';
				echo '<th class="table-header" >Telefono</th>';
				echo '<th class="table-header" >Encargado</th>';
				echo '<th class="table-header" >Correo de la Tienda</th>';
				echo '<th class="table-header" >Mapa</th>';
				echo '</tr>';
				echo '</thead>';
				echo '<tbody>';
				/*  
				Imprimir los resultados de la consulta.
				  - mysqli_fetch_assoc(): obtiene una fila de resultado como un array asociativo.
				*/
				$i = 1;
				while($row = mysqli_fetch_assoc($result)) {

				  echo '<tr>';
				  echo '<td>' . $i++ . '</td>';
				  echo '<td>' . $row['tienda'] . '</td>'; 
				  echo '<td>' . $row['direc_tienda'] . '</td>';
				  echo '<td>' . $row['telef_tienda'] . '</td>';
				  echo '<td>' . $row['encargado_tienda'] . '</td>';
				  echo '<td>' . $row['correo_tienda'] . '</td>';
				  echo '<td><a href="' . $row['mapa']  . '"><i class="fas fa-map"></i></a></td>';


				}
				echo '</tbody>';
				echo '</table>';
			  } else {
				echo '<p class="alert alert-warning">No hay resultados</p>';
			  }
			  mysqli_close($conexion);
		?>
			</br></br></br>
		<center>			
			<iframe src="https://www.google.com/maps/d/u/0/embed?mid=13091Cm0ltvWEXWjLbSiUzuMKRoo0FrFb" width="640" height="480"></iframe>
		</center>
			
			</br></br></br>
			<div class="form-group row">
                <div class="col-sm-10">
                    <a href="./index.php" class="btn btn-danger">Volver</a>
                </div>
            </div>	
	</div>
</body>
</html>