<?php

require('./config/db_connect.php');

if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
    $sql = 'UPDATE tiendas SET direc_tienda=?, telef_tienda=?, encargado_tienda=?, correo_tienda=?, mapa=? WHERE tienda=?';
    if ($stmt = mysqli_prepare($conexion, $sql)) {
        $tienda = $_POST['tienda'];
		$direc_tienda = $_POST['direc_tienda'];
		$telef_tienda = $_POST['telef_tienda'];
		$encargado_tienda = $_POST['encargado_tienda'];
        $correo_tienda = $_POST['correo_tienda'];
        $mapa = $_POST['mapa'];

        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt, 'sissss', $direc_tienda, $telef_tienda, $encargado_tienda, $correo_tienda, $mapa, $tienda);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue editado correctamente
            header("Location: admin_tienda.php?msg=2");
        }

        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);

} elseif (!empty($_GET['tienda'])) {
    $conexion = connect();
    $sql = 'SELECT * FROM tiendas WHERE tienda=?';
    
    # inicializa  una sentencia y devuelve un objeto para usarlo con mysqli_stmt_prepare()
    $stmt = mysqli_stmt_init($conexion);

    if (mysqli_stmt_prepare($stmt, $sql)) {
        
        # vincular parametros
        mysqli_stmt_bind_param($stmt, 's', $_GET['tienda']);

        # ejecutar consulta
        if (mysqli_stmt_execute($stmt)) {

            # vincular variables de resultados
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_array($result);
        

        $tienda = $_GET['tienda'];
		$direc_tienda = $row['direc_tienda'];
		$telef_tienda = $row['telef_tienda'];
		$encargado_tienda = $row['encargado_tienda'];
        $correo_tienda = $row['correo_tienda'];
        $mapa = $row['mapa'];
        $msg = '';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion); # cerrar la conexion
} else {
    $nom_usuario = '';
    $tienda = '';
    $direc_tienda = '';
    $telef_tienda = '';
    $encargado_tienda = '';
    $correo_tienda = '';
    $mapa = '';
    $msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>CRUD: Agregar</title>
</head>
<body>
   <!-- begin menu -->
   <?php include('./botones/menu3.php');?>
    <!-- end menu -->
    
    <div class="container">
        <h2 class="mt-5 text-uppercase">Editar</h2>

        <?php echo $msg; ?>

        <form action="./editar_tienda.php" method="POST">
            <div class="form-group row">
                <label for="tienda" class="col-sm-2 col-form-label">Nombre Tienda</label>
                <div class="col-sm-10">
                    <input type="tienda" class="form-control" id="tienda" name="tienda"  value="<?php echo $tienda;?>" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label for="direc_tienda" class="col-sm-2 col-form-label">Direccion Tienda</label>
                <div class="col-sm-10">
                    <input type="direc_tienda" class="form-control" id="direc_tienda" name="direc_tienda" value="<?php echo $direc_tienda;?>" autofocus>
                </div>
            </div>
            <div class="form-group row">
                <label for="telef_tienda" class="col-sm-2 col-form-label">Telefono Tienda</label>
                <div class="col-sm-10">
                    <input type="telef_tienda" class="form-control" id="telef_tienda" name="telef_tienda" value="<?php echo $telef_tienda;?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="encargado_tienda" class="col-sm-2 col-form-label">Encargado tienda</label>
                <div class="col-sm-10">
                    <input type="encargado_tienda" class="form-control" id="encargado_tienda" name="encargado_tienda" value="<?php echo $encargado_tienda;?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="correo_tienda" class="col-sm-2 col-form-label">Correo Tienda</label>
                <div class="col-sm-10">
                    <input type="correo_tienda" class="form-control" id="correo_tienda" name="correo_tienda" value="<?php echo $correo_tienda;?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="mapa" class="col-sm-2 col-form-label">Link Mapa</label>
                <div class="col-sm-10">
                    <input type="mapa" class="form-control" id="mapa" name="mapa" value="<?php echo $mapa;?>">
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <a href="./admin_tienda.php" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
        </body>
</html>
