<?php

require('./config/db_connect.php');
$msg='';
if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
	$sql = 'INSERT INTO `tiendas` (tienda, direc_tienda, telef_tienda, encargado_tienda, correo_tienda) VALUES (?, ?, ?, ?, ?)';	
    if ($stmt = mysqli_prepare($conexion, $sql)) {
		$tienda = $_POST['tienda'];
		$direc_tienda = $_POST['direc_tienda'];
		$telef_tienda = $_POST['telef_tienda'];
		$encargado_tienda = $_POST['encargado_tienda'];
		$correo_tienda = $_POST['correo_tienda'];
		
        
        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt, 'ssiss', $tienda, $direc_tienda, $telef_tienda, $encargado_tienda, $correo_tienda);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue agregado correctamente
            header("Location: tienda.php?msg=1");
        } else {
            # error al agregar registro
			$msg = '<p class="alert alert-danger">Oops! no fue posible agregar el registro.</p>';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);
} else {
    $tienda = '';
    $direc_tienda = '';
    $telef_tienda = '';
    $encargado_tienda = '';
	$correo_tienda = '';
	$msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>MOTO GUIDE Agregar tienda</title>
</head>
<body>
    <!-- begin menu -->
    <?php include('./botones/menu3.php');?>
    <!-- end menu -->
    
    <div class="container">
        <h2 class="mt-5 text-uppercase">Agregar tienda</h2>
        <?php echo $msg; ?>
		
        <form action="./agregar_tienda.php" method="post">
					<div class="form-group row">
						<label for="tienda" class="col-sm-2 col-form-label">Nombre de la Tienda</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="tienda" name="tienda" value="<?php echo $tienda;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="direc_tienda" class="col-sm-2 col-form-label">Direccion de la Tienda</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="direc_tienda" name="direc_tienda" value="<?php echo $direc_tienda;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="telef_tienda" class="col-sm-2 col-form-label">Telefono de la Tienda</label>
						<div class="col-sm-10">
							<input type="id" class="form-control" id="telef_tienda" name="telef_tienda" value="<?php echo $telef_tienda;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="encargado_tienda" class="col-sm-2 col-form-label">Encargado de Tienda</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="encargado_tienda" name="encargado_tienda" value="<?php echo $encargado_tienda;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="correo_tienda" class="col-sm-2 col-form-label">Correo de la Tienda</label>
						<div class="col-sm-10">
							<input type="email" class="form-control" id="correo_tienda" name="correo_tienda" value="<?php echo $correo_tienda;?>">
						</div>
					</div>
				<div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <a href="./tienda.php" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
		</form>    
    </div>  
</body>
</html>