<?php

require('./config/db_connect.php');
$email = '';
$mensaje = '';
$remitente = '';
$respuesta = '';
$msg = '';
if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
    $sql = 'UPDATE persona SET mensaje=?, remitente=?, respuesta=? WHERE email=?';
    if ($stmt = mysqli_prepare($conexion, $sql)) {
        $email = $_POST['email'];
        $mensaje = $_POST['mensaje'];
        $remitente = $_POST['remitente'];
        $respuesta = $_POST['respuesta'];        
        
        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt, 'ssss', $email, $mensaje, $remitente, $respuesta);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue editado correctamente
            header("Location: revision.php?msg=0");
        }

        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);

} elseif (!empty($_GET['email'])) {
    $conexion = connect();
    $sql = 'SELECT * FROM mensajes WHERE email=?';
    
    # inicializa  una sentencia y devuelve un objeto para usarlo con mysqli_stmt_prepare()
    $stmt = mysqli_stmt_init($conexion);

    if (mysqli_stmt_prepare($stmt, $sql)) {
        
        # vincular parametros
        mysqli_stmt_bind_param($stmt, 's', $_GET['email']);

        # ejecutar consulta
        if (mysqli_stmt_execute($stmt)) {

            # vincular variables de resultados
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_array($result);
            $email = $_GET['email'];
            $mensaje = $row['mensaje'];
            $remitente = $row['remitente'];
            $respuesta = $row['respuesta'];
            $msg = '';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion); # cerrar la conexion
} else {
    $email = '';
    $mensaje = '';
    $remitente = '';
    $respuesta = '';
    $msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>CRUD: Agregar</title>
</head>
<body>
   <!-- begin menu -->
   <?php include('./botones/menu3.php');?>
    <!-- end menu -->
    
    <div class="container">
        <h2 class="mt-5 text-uppercase">Editar</h2>

        <?php echo $msg; ?>

        <form action="./responder_mensaje.php" method="post">
            <div class="form-group row">
                <label for="email" class="col-sm-2 col-form-label">email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $email;?>" autofocus>
                </div>
            </div>
            <div class="form-group row">
                <label for="mensaje" class="col-sm-2 col-form-label">mensaje</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="mensaje" name="mensaje" value="<?php echo $mensaje;?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="remitente" class="col-sm-2 col-form-label">remitente</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="remitente" name="remitente" value="<?php echo $remitente;?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="respuesta" class="col-sm-2 col-form-label">respuesta</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="respuesta" name="respuesta" value="<?php echo $respuesta;?>">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                    <a href="./revision.php" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>