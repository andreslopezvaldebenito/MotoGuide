<?php
require('./config/db_connect.php');
if (!empty($_GET)) {
    # code...
    $email = $_GET['email'];
    $conexion = connect();
    $sql = 'DELETE FROM mensajes WHERE email = ?';

    if ($stmt = mysqli_prepare($conexion, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $email);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            mysqli_close($conexion);
            header("Location: revision.php?msg=1");
        }
    }
} else {
    header("Location: revision.php?msg=2");
}

?>