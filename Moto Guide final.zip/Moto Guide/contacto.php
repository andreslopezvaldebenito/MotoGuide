<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    

  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <title>MOTO GUIDE v1.0</title>
</head>
<body>
          <!-- begin menu -->
					<?php include('./botones/menu.php');?>
    <!-- end menu -->
    
	<div class="container">
		<table class="table">
			<h2 class="text-center"> <strong>Contacto</strong></h2>	 
		  <thead>
		    <tr>
		      <th scope="col">#</th>
		      <th scope="col">Nombre</th>
		      <th scope="col">Apellido</th>
		      <th scope="col">Correo</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <th scope="row">1</th>
		      <td>Daniel</td>
		      <td>Bustos</td>
		      <td>daniebutos@udec.cl</td>
		    </tr>
		    <tr>
		      <th scope="row">2</th>
		      <td>Andres</td>
		      <td>Lopez</td>
		      <td>andrelopez@udec.cl</td>
		    </tr>
		    <tr>
		      <th scope="row">3</th>
		      <td>Julio</td>
		      <td>Sanchez</td>
		      <td>jusanchez@udec.cl</td>
		    </tr>
		  </tbody>
		</table>
		</br></br>
<div class="form-group row">
                <div class="col-sm-10">
                    <a href="./index.php" class="btn btn-danger">Volver</a>
                </div>
            </div>
	</div>
	
</body>
</html>