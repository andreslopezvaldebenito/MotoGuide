<?php

require('./config/db_connect.php');
$msg='';
if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
	$sql = 'INSERT INTO `productos` (cod_producto, tipo_producto, descripcion_producto, tipo_moto, marca_moto, modelo_moto, tienda, precio_producto, imagen, mapa) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)';	
    if ($stmt = mysqli_prepare($conexion, $sql)) {
    	$cod_producto = $_POST['cod_producto'];
		$tipo_producto = $_POST['tipo_producto'];
		$descripcion_producto = $_POST['descripcion_producto'];
		$tipo_moto = $_POST['tipo_moto'];
		$marca_moto = $_POST['marca_moto'];
		$modelo_moto = $_POST['modelo_moto'];
		$tienda = $_POST['tienda'];
		$precio_producto = $_POST['precio_producto'];
		$imagen = $_POST['imagen'];
		$mapa = $_POST['mapa'];
		
        
        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt, 'issssssiss', $cod_producto, $tipo_producto, $descripcion_producto, $tipo_moto, $marca_moto, $modelo_moto, $tienda, $precio_producto,$imagen,$mapa);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue agregado correctamente
            header("Location: producto.php?msg=1");
        } else {
            # error al agregar registro
			$msg = '<p class="alert alert-danger">Oops! no fue posible agregar el registro.</p>';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);
} else {
    $cod_producto = '';
	$tipo_producto = '';
    $descripcion_producto = '';
    $tipo_moto = '';
    $marca_moto = '';
    $modelo_moto = '';
	$tienda = '';
	$precio_producto = '';
	$imagen='';
	$mapa='';
	$msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>MOTO GUIDE Agregar producto</title>
</head>
<body>
    <!-- begin menu -->
    <?php include('./botones/menu3.php');?>
    <!-- end menu -->
    
    <div class="container">
        <h2 class="mt-5 text-uppercase">Agregar Producto</h2>

        <?php echo $msg; ?>
		
        <form action="./agregar_producto.php" method="post">
					<div class="form-group row">
						<label for="cod_producto" class="col-sm-2 col-form-label">Codigo de Producto</label>
						<div class="col-sm-10">
							<input type="id" class="form-control" id="cod_producto" name="cod_producto" value="<?php echo $cod_producto;?>" required>
						</div>
					</div>
					<div class="form-group row">
						<label for="tipo_producto" class="col-sm-2 col-form-label">Tipo de producto</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="tipo_producto" name="tipo_producto" value="<?php echo $tipo_producto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="descripcion_producto" class="col-sm-2 col-form-label">Descripcion</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="descripcion_producto" name="descripcion_producto" value="<?php echo $descripcion_producto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="tipo_moto" class="col-sm-2 col-form-label">Tipo de moto </label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="tipo_moto" name="tipo_moto" value="<?php echo $tipo_moto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="marca_moto" class="col-sm-2 col-form-label">Marca de moto</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="marca_moto" name="marca_moto" value="<?php echo $marca_moto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="modelo_moto" class="col-sm-2 col-form-label">Modelo de moto</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="modelo_moto" name="modelo_moto" value="<?php echo $modelo_moto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="tienda" class="col-sm-2 col-form-label">Nombre Tienda</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="tienda" name="tienda" value="<?php echo $tienda;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="precio_producto" class="col-sm-2 col-form-label">Precio del producto</label>
						<div class="col-sm-10">
							<input type="id" class="form-control" id="precio_producto" name="precio_producto" value="<?php echo $precio_producto;?>"required>
						</div>
					</div>
					<div class="form-group row">
						<label for="imagen" class="col-sm-2 col-form-label">Link de Imagen</label>
						<div class="col-sm-10">
							<input type="id" class="form-control" id="imagen" name="imagen" value="<?php echo $imagen;?>">
						</div>
					</div>
					<div class="form-group row">
						<label for="mapa" class="col-sm-2 col-form-label">Link del Mapa</label>
						<div class="col-sm-10">
							<input type="mapa" class="form-control" id="mapa" name="mapa" value="<?php echo $mapa;?>">
						</div>
					</div>
			<div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Guardar Producto</button>
                    <a href="./producto.php" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
		</form>    
    </div>  
</body>
</html>