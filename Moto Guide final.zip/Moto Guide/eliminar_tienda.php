<?php
require('./config/db_connect.php');
if (!empty($_GET)) {
    # code...
    $tienda = $_GET['tienda'];
    $conexion = connect();
    $sql = 'DELETE FROM tiendas WHERE tienda = ?';

    if ($stmt = mysqli_prepare($conexion, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $tienda);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            mysqli_close($conexion);
            header("Location: admin_tienda.php?msg=3");
        }
    }
} else {
    header("Location: admin_tienda.php?msg=4");
}

?>