<?php

require('./config/db_connect.php');

if (!empty($_POST)) {
    $conexion = connect();
    /* 
    mysqli_prepare(): prepara una sentencia SQL para su ejecución. Retorna:
        - FALSE si ocurre un error.
        - TRUE si todo ok.
    */
	$sql = 'INSERT INTO `mensajes` (email, mensaje) VALUES (?, ?)';	
    if ($stmt = mysqli_prepare($conexion, $sql)) {
		$email = $_POST['email'];
        $mensaje = $_POST['mensaje'];
        $msg='';

        
        # Aqui, se deben agregar las validaciones de los datos.

        /*
        mysqli_stmt_bind_param() agregar variables a una sentencia preparada como parametros.
            - Tipos de datos: {S}tring - {I}nt - {D}ouble.
        */
        mysqli_stmt_bind_param($stmt, 'ss', $email, $mensaje);

        /*
        # mysqli_stmt_execute() ejecuta la sentencia preparada: 
            - TRUE en caso de éxito o 
            - FALSE en caso de error. 
            - mysqli_stmt_affected_rows() permite determinar el número total de filas afectadas. 
        */
        if (mysqli_stmt_execute($stmt)) {
            # el registro fue agregado correctamente
            header("Location: index.php?msg=1");
        } else {
            # error al agregar registro
			$msg = '<p class="alert alert-danger">Oops! no fue posible enviar el mensaje.</p>';
        }
        mysqli_stmt_close($stmt); # cerrar sentencia
    }
    mysqli_close($conexion);
} else {
    $email = '';
    $mensaje = '';
	$msg = '';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>MOTO GUIDE Enviar mensaje</title>
</head>
<body>
        <!-- begin menu -->
        <?php include('./botones/menu.php');?>
    <!-- end menu -->
        <div class="container">
        <h2 class="mt-5 text-uppercase">Enviar mensaje a desarrolladores</h2>
        
            <?php echo $msg; ?>
            
            <form action="./mensaje.php" method="post">
                   <div class="form-group row">
                        <label for="email" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $email;?>">
                            </div>
                    </div>
                    <div class="form-group row">
                        <label for="mensaje" class="col-sm-2 col-form-label">Mensaje</label>
                            <div class="col-sm-10">
                                <textarea type="text" maxlength="400" id="mensaje" name="mensaje" rows="5" class="form-control" value="<?php echo $mensaje;?>"></textarea>
                            </div>	
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary" action="mensaje.php">Enviar Mensaje</button>
                            <a href="./index.php" class="btn btn-danger">Volver</a>
                        </div>
                    </div>
		    </form>    
        </div>  
</body>
</html>