
<!-- Barra menu obtenida de bootstrap-->

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="./administrador.php">Inicio Moto-Guide</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="./producto.php">Adm, Productos</a></li>
      <li><a href="./admin_tienda.php">Adm. Tiendas</a></li>
      <li><a href="./usuario.php">Usuarios</a></li>
      <li><a href="./revision.php">Mensajes</a></li>
      <li><a href="./">Salir</a></li>
    </ul>
  </div>
</nav>



