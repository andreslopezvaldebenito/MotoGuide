<?php
if(isset($_POST['palabra'])){
    require_once "filtro.php";
    require_once 'config/db_connect.php';
}

?>

<!-- Barra menu obtenida de bootstrap-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="./">Inicio Moto-Guide</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="./productos.php">MG te ofrece estos productos</a></li>
      <li><a href="./tienda.php">Conoce las tiendas de L.A</a></li>
      <li><a href="./ingreso.php">Administrador</a></li>
      <li><a href="./contacto.php">Contactos</a></li>
      <li><a href="./mensaje.php">Enviar msje a desarrolladores</a></li>
    </ul>
    <form class="navbar-form navbar-left" action="buscar2.php" method="POST">
      <div class="form-group">
        <input type="text" id="palabra" name="palabra" class="form-control" placeholder="Búsqueda por Palabras">
      </div>
      <button type="submit" class="btn btn-default">Buscar</button>
    </form>
  </div>
</nav>

