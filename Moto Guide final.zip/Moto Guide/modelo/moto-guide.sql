-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-07-2018 a las 22:51:31
-- Versión del servidor: 10.1.32-MariaDB
-- Versión de PHP: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `moto-guide`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `email` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `mensaje` text COLLATE utf8_spanish_ci NOT NULL,
  `remitente` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `respuesta` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`email`, `mensaje`, `remitente`, `respuesta`) VALUES
('dmasias@udec.cl', 'Ver sistema', 'andrelopez', NULL),
('usuario@prueba.cl', 'Hla esta es un prueba', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `cod_producto` int(11) NOT NULL,
  `tipo_producto` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion_producto` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_moto` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `marca_moto` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `modelo_moto` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tienda` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `precio_producto` int(11) NOT NULL,
  `imagen` text COLLATE utf8_spanish_ci,
  `mapa` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`cod_producto`, `tipo_producto`, `descripcion_producto`, `tipo_moto`, `marca_moto`, `modelo_moto`, `tienda`, `precio_producto`, `imagen`, `mapa`) VALUES
(1, 'Moto', 'Moto de Calle Suzuki Gixxer DI 150 cc', 'Calle', 'Suzuki', 'Gixxer DI', 'Suzuki', 1599900, 'http://www.rutamotor.com/wp-content/uploads/2015/08/LATIN_AMERICA_GSX150_Blue_SideB.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(2, 'Moto', 'Moto Calle Suzuki GSX 250 R 250 cc', 'Calle', 'Suzuki', 'GSX 250 R', 'Suzuki', 3699900, 'https://www.motofichas.com//images/phocagallery/Suzuki/GSX-R250_2017/01-suzuki-gsx-r250-2017.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(4, 'Moto', 'Moto Scooter Suzuki AN650Z 650 cc', 'Scooter', 'Suzuki', 'AN650Z', 'Suzuki', 8499900, 'https://www.dercomotos.cl/content/uploads/sites/2/bfi_thumb/AN650Z-Burgman-nqmrnkcq71hff6ympg2q0a18fcmfo2zyo58anurdzc.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(5, 'Moto', 'Moto Deportiva Suzuki GSX-S750A 750 cc', 'Deportiva', 'Suzuki', 'GSX-S750A', 'Suzuki', 7999900, 'https://api.motorpress-iberica.es/motociclismo-fichas/api/v1/images/modelo/588b3c36f5ccae393ae42dc0.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(6, 'Moto', 'Moto Deportiva Suzuki HAYABUSA 1300 cc', 'Deportiva', 'Suzuki', 'HAYABUSA', 'Suzuki', 11499900, 'http://d3jth7oi254ls0.cloudfront.net/media/images/product/suzuki_gsx_r_1300_hayabusa_43_3.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(7, 'Moto', 'Moto Deportiva Suzuki GSX-R1000R 1000 cc', 'Deportiva', 'Suzuki', 'GSX-R1000R', 'Suzuki', 15990900, 'http://bikereview.com.au/wp-content/uploads/2017/02/BikeReview-2017-Suzuki-GSX-R1000R20170204_1329.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(8, 'Moto', 'Moto Multiproposito Suzuki DR200S 200 cc', 'Multiproposito', 'Suzuki', 'DR200S', 'Suzuki', 2999900, 'https://www.ubikemotos.cl/414-thickbox_default/suzuki-dr-200s.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(9, 'Moto', 'Moto Multiproposito Suzuki Vstrom 1000XT 1000 cc', 'Multiproposito', 'Suzuki', 'Vstrom 1000XT', 'Suzuki', 10499900, 'https://i2.wp.com/motocostarica.com/wp-content/uploads/2017/08/2018-Suzuki-V-Strom-1000-y-1000XT.jpg?fit=1620%2C1080&ssl=1', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(10, 'Moto', 'Moto Motocross Suzuki RMZ450 450 cc ', 'Motocross', 'Suzuki', 'RMZ450', 'Suzuki', 6999000, 'https://2yrh403fk8vd1hz9ro2n46dd-wpengine.netdna-ssl.com/wp-content/uploads/2017/06/2018-Suzuki-RM-Z450-First-Look-Motocross-Motorcycle-1.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(11, 'Moto', 'Moto Motocross Suzuki RMZ250 250 cc', 'Motocross', 'Suzuki', 'RMZ250', 'Suzuki', 6499900, 'https://i.ytimg.com/vi/O_1rS7dr8zo/maxresdefault.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(12, 'Moto', 'Moto Calle Honda CB190R 190 cc', 'Calle', 'Honda', 'CB190R', 'Honda', 1690000, 'https://honda-chile-production.s3.amazonaws.com/uploads/imagen/archivo/459/ColorNegro.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(13, 'Moto', 'Moto Calle Honda CBR300R 300 cc', 'Calle', 'Honda', 'CBR300R', 'Honda', 2990000, 'https://www.motofichas.com//images/phocagallery/Honda/CBR300R/01-honda_cbr300r-tricolor-34.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(14, 'Moto', 'Moto Calle Honda CB1 Race Cross cc', 'Calle', 'Honda', 'CB1', 'Honda', 699000, 'https://honda-chile-production.s3.amazonaws.com/uploads/imagen/archivo/544/disenocb101.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(15, 'Moto', 'Moto Calle Honda CB500F 500 cc', 'Calle', 'Honda', 'CB500F', 'Honda', 4950000, 'https://ic1.maxabout.us/autos/tw_india//H/2017/3/honda-cb500f.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(16, 'Moto', 'Moto Multiproposito Honda Africa twin 1000 cc', 'Multiproposito', 'Honda', 'Africa twin', 'Honda', 11990000, 'https://api.motorpress-iberica.es/motociclismo-fichas/api/v1/images/modelo/55b1ef515f276fd6090a8f0d.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(17, 'Moto', 'Moto Multiproposito Honda VFR1200 1200 cc', 'Multiproposito', 'Honda', 'VFR1200', 'Honda', 9990000, 'https://i.ytimg.com/vi/Uj8_LL8vBp4/maxresdefault.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(18, 'Moto', 'Moto Deportiva Honda CBR600RR 600 cc', 'Deportiva', 'Honda', 'CBR600RR', 'Honda', 8990000, 'https://autoblog.com.ar/motoblog/wp-content/uploads/2017/06/CBR600RR_2017_03.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(19, 'Moto', 'Moto Deportiva Honda CBR1000RR FIREBLADE 1000 cc', 'Deportiva', 'Honda', 'CBR1000RR FIREBLADE', 'Honda', 12990000, 'http://stat.overdrive.in/wp-content/uploads/2016/11/Honda-CBR-1000RR-Fireblade-2.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(20, 'Moto', 'Moto Motocross Honda CRF450R 450 cc', 'Motocross', 'Honda', 'CRF450R', 'Honda', 7490000, 'https://i.ytimg.com/vi/s-nyJbY8Ofc/maxresdefault.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(22, 'Moto', 'Moto Calle Yamaha FZ25 250 cc', 'Calle', 'Yamaha', 'FZ25', 'Yamaha', 2290000, 'https://media.zigcdn.com/media/model/2017/Jan/yahama-fz25-right_600x300.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(24, 'Moto', 'Moto Deportiva Yamaha MT-10 1000 cc', 'Deportiva', 'Yamaha', 'MT-10', 'Yamaha', 10990000, 'https://cdn.yamaha-motor.eu/product_assets/2018/MT10/950-75/2018-Yamaha-MT-10-EU-Yamaha-Blue-Studio-001.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(25, 'Moto', 'Moto Deportiva Yamaha YZF-R1 1000 cc', 'Deportiva', 'Yamaha', 'YZF-R1', 'Yamaha', 13390000, 'http://www.yamahamotos.cl/wp-content/uploads/2016/09/R1_producto.png', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(26, 'Moto', 'Moto Motocross Yamaha YZ-250X 250 cc', 'Motocross', 'Yamaha', 'YZ-250X', 'Yamaha', 5290000, 'http://www.yamahamotos.cl/wp-content/uploads/2016/12/img-2.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(27, 'Accesorio', 'Accesorio Manubrio Moto Renthal', '', 'Honda', 'Africa twin', 'Yamaha', 19990, 'https://http2.mlstatic.com/D_Q_NP_984922-MLM27064885258_032018-Q.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(28, 'Accesorio', 'Accesorio Puno moto Protaper', '', 'Honda', 'CB1', 'Honda', 14990, 'https://http2.mlstatic.com/para-moto-punos-D_NQ_NP_937721-MLM20826476975_072016-F.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(29, 'Accesorio', 'Accesorio Antiparra Piloto Oakley', '', '', '', 'Suzuki', 12990, 'https://http2.mlstatic.com/oakley-oo7005n-26-palanca-para-ojos-la-fabrica-piloto-de-D_NQ_NP_605621-MLC26468131376_122017-O.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(30, 'Accesorio', 'Accesorio Casco veloce gt Piloto AGV', '', '', '', 'Suzuki', 359990, 'https://s-media-cache-ak0.pinimg.com/originals/2b/9e/08/2b9e08dcdb655372868753b5bfe6e4b4.jpg', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
(31, 'Accesorio', 'Accesorio Escape Moto Yoshimura', '', 'Suzuki', 'GSX-S750A', 'Honda', 89990, 'https://http2.mlstatic.com/escape-yoshimura-carbono-honda-crf-250r-2010-13-motocross-D_NQ_NP_945770-MLA26976144883_032018-F.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(32, 'Accesorio', 'Accesorio Espejo retractiles Moto Rizoma', '', 'Yamaha', 'XA-Race Cross', 'Yamaha', 15990, 'https://www.megamotos.com/2590-tm_home_default/rizoma-espejo-pequeno.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(33, 'Accesorio', 'Accesorio Guantes Piloto Alpinestars', '', '', '', 'Yamaha', 159990, 'https://www.motorbikemag.es/tienda/wp-content/uploads/2017/09/Guantes-Alpinestars-Supertech-M%C3%A1rquez-Maze-1.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(34, 'Accesorio', 'Accesorio Balaclava Piloto Alpinestars', '', '', '', 'Honda', 22900, 'https://www.ubikemotos.cl/2595/1707.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(35, 'Accesorio', 'Accesorio Led 8000lm Moto', '', '', '', 'Yamaha', 19200, 'https://http2.mlstatic.com/bombillo-luz-led-8000lm-h4-moto-y-carro-D_NQ_NP_951110-MCO27299602651_052018-F.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(36, 'Accesorio', 'Accesorio Manillas Moto Yamaha', '', 'Yamaha', 'YZ-250X', 'Yamaha', 5990, 'https://http2.mlstatic.com/manillas-moto-honda-racing-ride-it-D_NQ_NP_637349-MLC26926830212_022018-F.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(37, 'Accesorio', 'Accesorio Botas Piloto Gaerne', '', '', '', 'Yamaha', 250000, 'https://motocard.s3.amazonaws.com/products/images/02646/sg_12_yellow_049-1-M-02646450-xlarge.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(38, 'Accesorio', 'Accesorio Calcetines Piloto Alpinestars', '', '', '', 'Honda', 9990, 'https://zambudiomotorsport.es/wp-content/uploads/2016/12/calcetines-alpinestars-kx-winter-socks-4706012.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(39, 'Repuesto', 'Repuesto Aceite Castrol 10W-50 Full sintetico', '', 'Suzuki', 'GSX-S750A', 'Yamaha', 14990, 'http://www.tiempodemotos.cl/wp-content/uploads/2017/02/aceite-moto-castrol-power-1-10w50-100-sintetico-D_NQ_NP_182721-MLU20827808470_072016-O.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(40, 'Repuesto', 'Repuesto Aceite Castrol 10W-40 semi sintetico', '', 'Honda', 'CBR300R', 'Honda', 9500, 'https://http2.mlstatic.com/aceite-castrol-10w40-4t-x-tra-semi-sintetico-ryd-motos-D_NQ_NP_732331-MLA25974203901_092017-F.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(41, 'Repuesto', 'Repuesto Bujia NGK CR8E estandar', '', '', '', 'Yamaha', 7990, 'http://www.recambio-moto.com/874-large_default/bujia-ngk-cr8e.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(42, 'Repuesto', 'Repuesto Bujia NGK CR9E iridium', '', 'Yamaha', 'YZF-R1', 'Yamaha', 12990, 'http://www.expomoto.net/11211-large/bujia-ngk-cr9ei.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(43, 'Repuesto', 'Repuesto Aceite Motul 10W-30 full sintetico', '', 'Yamaha', 'FZ25', 'Honda', 12990, 'http://cdn6.bigcommerce.com/s-hs643j/products/167/images/527/3D_Bidon_Motul_1L_7100_10W30__97055.1406586082.451.416.png?c=2', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(44, 'Repuesto', 'Repuesto Aceite Repsol 15W-50 semi sintetico', '', '', '', 'Honda', 6500, 'https://www.rodando.cl/wp-content/uploads/2017/03/Repsol-Raider-15w50-480x480.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(45, 'Repuesto', 'Repuesto Bujia GONHER CR8E estandar', '', '', '', 'Yamaha', 6990, 'https://gonher-production.s3.amazonaws.com/uploads/files/generic_file/file/192/buj_as-P-Lamding.png', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(46, 'Repuesto', 'Repuesto Bujia BOSCH CR9E iridium', '', '', '', 'Yamaha', 10900, 'https://http2.mlstatic.com/4x-bujias-alemanas-bosch-iridium-yr6ni332s-D_NQ_NP_911511-MLA20556991434_012016-F.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(47, 'Repuesto', 'Repuesto Aceite bel_ray 20W-50 full sintetico', '', '', '', 'Honda', 15990, 'https://www.wwag.com/step/800/23202.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(48, 'Repuesto', 'Repuesto Aceite Amsoil 10W-40 semi sintetico', '', 'Honda', 'CBR1000RR FIREBLADE', 'Yamaha', 9990, 'https://i.ebayimg.com/images/g/g1IAAOSwADtaqDyv/s-l300.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108'),
(49, 'Repuesto', 'Repuesto Bujia Champion CR9E iridium', '', '', '', 'Honda', 11990, 'https://www.francobordo.com/images/productos/bujias-champion-1-4835.jpg', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
(50, 'Repuesto', 'Repuesto Bujia Acdelco CR8E estandar', '', '', '', 'Yamaha', 6790, 'https://ae01.alicdn.com/kf/HTB1t0EZfL1TBuNjy0Fjq6yjyXXaB/2pcs-lot-Motorcycle-Spark-Plug-B7TC-for-CR7E-CPR7EA-9-CPR8EA-9-CPR8EAIX-9-96067-CR8E.jpg_220x220.jpg', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE `tiendas` (
  `tienda` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direc_tienda` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `telef_tienda` int(9) NOT NULL,
  `encargado_tienda` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `correo_tienda` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `mapa` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`tienda`, `direc_tienda`, `telef_tienda`, `encargado_tienda`, `correo_tienda`, `mapa`) VALUES
('Honda', 'Mendoza 815', 432316987, 'Camila Robles', 'motostopchile@yahoo.es', 'https://www.google.com/maps/place/Motostop/@-37.4637159,-72.354123,18.42z/data=!4m5!3m4!1s0x966bdd474ac7db17:0x88984ec6279890e3!8m2!3d-37.4637105!4d-72.3534116'),
('Suzuki', 'Av. Alemania 410', 432325776, 'Anibal Matamala', 'mxlosangeles@gmail.com', 'https://www.google.com/maps/place/MXMarchioni/@-37.469409,-72.343182,18z/data=!4m5!3m4!1s0x966bdd4fd6f006bf:0x1405d44af4af1ee2!8m2!3d-37.469409!4d-72.343182'),
('Yamaha', 'Galvarino #487', 432316987, 'Esteban Fernandez', 'motostop.yamaha@gmail.com', 'https://www.google.com/maps/place/Galvarino+488,+Los+Angeles,+Los+%C3%81ngeles,+Regi%C3%B3n+del+B%C3%ADo+B%C3%ADo/@-37.4638784,-72.3554995,17z/data=!3m1!4b1!4m5!3m4!1s0x966bdd47358a7905:0x5bd43a459712e7d8!8m2!3d-37.4638827!4d-72.3533108');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `nom_usuario` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `contrasena` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `ciudad` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` int(9) NOT NULL,
  `tienda` varchar(30) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nom_usuario`, `email`, `contrasena`, `nombre`, `apellidos`, `direccion`, `ciudad`, `telefono`, `tienda`) VALUES
('andrelopez', 'andrelopez@udec.cl', '12345678', 'Andres', 'Lopez Valdebenito', 'Baquedano #203', 'Nacimiento', 975553565, 'Yamaha'),
('daniebustos', 'dniebustos@udec.cl', '12345678', 'Daniel', 'Bustos', 'Valencia #440 Villa Espana', 'Los Angeles', 979551744, 'Suzuki');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`email`),
  ADD KEY `remitente` (`remitente`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`cod_producto`),
  ADD KEY `tienda` (`tienda`);

--
-- Indices de la tabla `tiendas`
--
ALTER TABLE `tiendas`
  ADD PRIMARY KEY (`tienda`),
  ADD UNIQUE KEY `encargado_tienda_2` (`encargado_tienda`),
  ADD KEY `encargado_tienda` (`encargado_tienda`),
  ADD KEY `encargado_tienda_3` (`encargado_tienda`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`nom_usuario`),
  ADD KEY `tienda` (`tienda`),
  ADD KEY `tienda_2` (`tienda`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`remitente`) REFERENCES `usuarios` (`nom_usuario`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`tienda`) REFERENCES `tiendas` (`tienda`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`tienda`) REFERENCES `tiendas` (`tienda`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
