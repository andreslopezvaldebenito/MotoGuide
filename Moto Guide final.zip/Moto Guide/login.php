<?php

$nom_usuario1 = $_POST['nom_usuario'];
$contrasena1 = $_POST['contrasena'];

if(empty($nom_usuario1) || empty($contrasena1)){
	header("Location: ingreso.php");
	exit();
}

$conexion=require('config/db_connect.php');
$conexion = connect();
$consulta = "SELECT * FROM usuarios WHERE nom_usuario = '$nom_usuario1'";
/*$consulta = "SELECT * FROM usuarios WHERE nom_usuario = '{$_POST['nom_usuario']}' AND contrasena = '{$_POST['contrasena']}'";*/
$result = mysqli_query ($conexion, $consulta);

if($row = mysqli_fetch_array($result)){
	if($row['contrasena'] ==  $contrasena1){
		session_start();
		$_SESSION['nom_usuario'] = $nom_usuario1;
		header("Location: administrador.php");
	}else{
		header("Location: ingreso.php");
		exit();
	}
}else{
	header("Location: ingreso.php");
	exit();
}

?>