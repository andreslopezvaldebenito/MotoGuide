<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
   
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <title>MOTO GUIDE v1.0</title>
</head>
<body>
    <!-- begin menu -->
    <?php include('./botones/menu.php');?>
    <!-- end menu -->
    
	<div class="container">
		<h2 class="text-center"> <strong>Moto-Guide</strong></h2>
		<h3 class="text-center"> <strong>Bienvenido al sitio número 1 en la búsqueda de locales, accesorios y respuestos relacionados con motocicletas en la ciudad de Los Ángeles</strong></h3>	 
		<h4 class="text-center"> <strong>(La búsqueda de informacion y consultas es realizada en el menú ubicado en la parte superior de la pantalla)</strong></h3>	 
		  <div id="myCarousel" class="carousel slide" data-ride="carousel">
		    <!-- Indicators -->
		    <ol class="carousel-indicators">
		      <li data-target="#myCarousel" data-slide-to="0"></li>
		      <li data-target="#myCarousel" data-slide-to="1"></li>
		      <li data-target="#myCarousel" data-slide-to="2"></li>
		      <li data-target="#myCarousel" data-slide-to="3"></li>
		    </ol>

		    <!-- Wrapper for slides -->
		    <div class="carousel-inner" >
		      <div class="item active" >
		      	<div class= "numbertext">1/4 </div>
		        	<img src="./imagenes/dos.jpg" alt="rossi" style="width:100%;">
		      </div>

		      <div class="item">
		      	<div class= "numbertext">2/4 </div>
		        	<img src="./imagenes/uno.jpg" alt="marquez" style="width:100%;">
		      </div>
		    
		      <div class="item">
		      	<div class= "numbertext">3/4 </div>
		        <img src="./imagenes/tres.jpg" alt="cross" style="width:100%;">
		      </div>

		      <div class="item">
		      	<div class= "numbertext">4/4 </div>
		        <img src="./imagenes/cuatro.jpg" alt="enduro" style="width:100%;">
		      </div>
		    </div>

		    <!-- Left and right controls -->
		    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
		      <span class="glyphicon glyphicon-chevron-left"></span>
		      <span class="sr-only">Previous</span>
		    </a>
		    <a class="right carousel-control" href="#myCarousel" data-slide="next">
		      <span class="glyphicon glyphicon-chevron-right"></span>
		      <span class="sr-only">Next</span>
		    </a>
		  </div>

	</div>
	
	<div class="container hidden-xs hidden-sm">
	  <h2 class="text-center"> <strong>Distribuidores oficiales de motos</strong></h2>
	  <div class="row">
	    <div class="col-md-4">
	      <div class="thumbnail">
	        <a href="https://www.suzukimotos.cl/" target="_blank">
	          <img src="./imagenes/Suzuki.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-4">
	      <div class="thumbnail">
	        <a href="https://motos.honda.cl/" target="_blank">
	          <img src="./imagenes/honda.jpg" alt="Nature" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-4">
	      <div class="thumbnail">
	        <a href="http://www.yamahamotos.cl/" target="_blank">
	          <img src="./imagenes/yamaha.jpg" alt="Fjords" style="width:300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	  </div>
	</div>

	<br><br><br>

	<div class="container hidden-xs hidden-sm">
	  <h2 class="text-center"> <strong>Nuestras marcas</strong></h2>
	  <div class="row">
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.agv.com/gb_en/" target="_blank">
	          <img src="./imagenes/agv.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="http://www.oakleychile.cl/" target="_blank">
	          <img src="./imagenes/Oakley.jpg" alt="Nature" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.protaper.com/" target="_blank">
	          <img src="./imagenes/protaper.jpg" alt="Fjords" style="width:300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.renthal.com/" target="_blank">
	          <img src="./imagenes/renthal.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="http://www.yoshimura-rd.com/" target="_blank">
	          <img src="./imagenes/yoshimura.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="http://www.rizoma.com/" target="_blank">
	          <img src="./imagenes/rizoma.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	  </div>

	  <div class="row">
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.alpinestars.com/" target="_blank">
	          <img src="./imagenes/alpin.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="http://www.gaerne.com/" target="_blank">
	          <img src="./imagenes/gaerne.jpg" alt="Nature" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.castrol.com/es_cl/chile.html" target="_blank">
	          <img src="./imagenes/castrol.jpg" alt="Fjords" style="width:300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.ngk.de/nc/es/buscador-de-productos/" target="_blank">
	          <img src="./imagenes/ngk.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://belray.cl/" target="_blank">
	          <img src="./imagenes/bell.png" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	    <div class="col-md-2">
	      <div class="thumbnail">
	        <a href="https://www.repsol.com/es/index.cshtml" target="_blank">
	          <img src="./imagenes/rep.jpg" alt="Lights" style="width: 300px; height: 100px;">
	        </a>
	      </div>
	    </div>
	  </div>





















	</div>



</body>
</html>