<?php
require('./config/db_connect.php');
if (!empty($_GET)) {
    # code...
    $cod_producto = $_GET['cod_producto'];
    $conexion = connect();
    $sql = 'DELETE FROM productos WHERE cod_producto = ?';

    if ($stmt = mysqli_prepare($conexion, $sql)) {
        mysqli_stmt_bind_param($stmt, 'i', $cod_producto);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            mysqli_close($conexion);
            header("Location: producto.php?msg=3");
        }
    }
} else {
    header("Location: producto.php?msg=4");
}

?>