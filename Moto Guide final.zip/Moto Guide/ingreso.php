<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <title>MOTO GUIDE Ingreso</title>
</head>
<body>
         <!-- begin menu -->
         <?php include('./botones/menu.php');?>
    <!-- end menu -->
    
	 <div class="container">
     <h2 class="mt-5 text-uppercase">Ingresar Administrador</h2>
     <br>
        <form action="login.php" method="POST">
			<div class="form-group row">
                <label for="nom_usuario" class="col-sm-2 col-form-label">Nombre de Usuario</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nom_usuario" name="nom_usuario" required>
                </div>
            </div>
			<div class="form-group row">
                <label for="contrasena" class="col-sm-2 col-form-label">Contraseña</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" id="contrasena" name="contrasena"required>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10">
                    <button type="submit" href="./administrador.php" class="btn btn-primary" value="LOGIN">Ingresar</button>
                    <a href="./index.php" class="btn btn-danger">Volver</a>
                </div>
            </div>
        </form>
	</div>
</body>

<body>
	<div class="col-sm-10">
		<a class="navbar-brand" href="./administrador.php">Ingreso para revision de fuciones de Administrador</a>
	</div>
</body>
</html>